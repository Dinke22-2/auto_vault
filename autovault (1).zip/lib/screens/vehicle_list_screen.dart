import 'package:flutter/material.dart';

class VehicleListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Your Vehicles')),
      body: ListView(
        children: [
          ListTile(
            title: Text('Toyota Corolla (ABC123)'),
            subtitle: Text('Last Service: Jan 15, 2024'),
            trailing: Icon(Icons.arrow_forward),
          ),
          ListTile(
            title: Text('Honda Civic (XYZ789)'),
            subtitle: Text('Last Service: Dec 10, 2023'),
            trailing: Icon(Icons.arrow_forward),
          ),
        ],
      ),
    );
  }
}
