import 'package:flutter/material.dart';
import 'vehicle_list_screen.dart';
import 'add_vehicle_screen.dart';
import 'service_logs_screen.dart';
import 'admin_panel_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('AutoVault - Home')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => VehicleListScreen()),
              ),
              child: Text('View Vehicles'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AddVehicleScreen()),
              ),
              child: Text('Add Vehicle'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ServiceLogsScreen()),
              ),
              child: Text('Service Logs'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AdminPanelScreen()),
              ),
              child: Text('Admin Panel'),
            ),
          ],
        ),
      ),
    );
  }
}
