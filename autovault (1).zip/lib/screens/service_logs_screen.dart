import 'package:flutter/material.dart';

class ServiceLogsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Service Logs')),
      body: Center(child: Text('Service history will be displayed here.')),
    );
  }
}
