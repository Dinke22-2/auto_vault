import 'package:flutter/material.dart';

class AddVehicleScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Add Vehicle')),
      body: Center(child: Text('Form to add vehicle will go here.')),
    );
  }
}
