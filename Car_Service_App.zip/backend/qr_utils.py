import qrcode
import os

def generate_qr(vehicle_id, reg_no):
    qr = qrcode.make(f"Vehicle ID: {vehicle_id}, Reg No: {reg_no}")
    qr.save(f"static/{reg_no}.png")
