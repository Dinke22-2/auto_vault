from flask import Flask, request, jsonify
from database import db, User, Vehicle
from qr_utils import generate_qr
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///car_service.db'
db.init_app(app)

@app.route('/register', methods=['POST'])
def register():
    data = request.json
    user = User(email=data['email'], password=data['password'])
    db.session.add(user)
    db.session.commit()
    return jsonify({'message': 'User registered successfully'}), 201

@app.route('/add_vehicle', methods=['POST'])
def add_vehicle():
    data = request.json
    vehicle = Vehicle(owner_id=data['owner_id'], make=data['make'], model=data['model'], reg_no=data['reg_no'])
    db.session.add(vehicle)
    db.session.commit()
    generate_qr(vehicle.id, vehicle.reg_no)
    return jsonify({'message': 'Vehicle added successfully'}), 201

if __name__ == '__main__':
    app.run(debug=True)
