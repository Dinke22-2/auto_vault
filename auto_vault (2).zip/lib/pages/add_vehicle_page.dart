import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AddVehiclePage extends StatefulWidget {
  const AddVehiclePage({Key? key}) : super(key: key);

  @override
  _AddVehiclePageState createState() => _AddVehiclePageState();
}

class _AddVehiclePageState extends State<AddVehiclePage> {
  final _makeController = TextEditingController();
  final _modelController = TextEditingController();
  final _regNumberController = TextEditingController();

  Future<void> addVehicle() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      await FirebaseFirestore.instance.collection('vehicles').add({
        'make': _makeController.text.trim(),
        'model': _modelController.text.trim(),
        'registration_number': _regNumberController.text.trim(),
        'owner_id': user.uid,
      });
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Vehicle')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(controller: _makeController, decoration: const InputDecoration(labelText: 'Make')),
            TextField(controller: _modelController, decoration: const InputDecoration(labelText: 'Model')),
            TextField(controller: _regNumberController, decoration: const InputDecoration(labelText: 'Registration Number')),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: addVehicle, child: const Text('Add Vehicle')),
          ],
        ),
      ),
    );
  }
}
