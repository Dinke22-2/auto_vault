import 'package:flutter/material.dart';
import 'package:qrcode_reader/qrcode_reader.dart';

class QRCodeScanner extends StatefulWidget {
  @override
  _QRCodeScannerState createState() => _QRCodeScannerState();
}

class _QRCodeScannerState extends State<QRCodeScanner> {
  
  String result = "";

  Future<void> scanQRCode() async {
    String scannedResult = await QRCodeReader().scan();
    setState(() {
      result = scannedResult;
    });
    
    // Here you can navigate to the service history page using the scanned result.
    
   // Example:
   // Navigator.push(context, MaterialPageRoute(builder:(context)=> ServiceHistoryPage(vehicleId : result)));
    
   }

   @override
   Widget build(BuildContext context) {
     return Scaffold(
       appBar : AppBar(title : Text("QR Code Scanner")),
       body : Center(
         child : Column(
           mainAxisAlignment : MainAxisAlignment.center,
           children : <Widget>[
             ElevatedButton(onPressed : scanQRCode , child : Text("Scan QR Code")),
             SizedBox(height :20),
             Text(result.isEmpty ? "Scan a QR code" : result)
           ],
         ),
       ),
     );
   }
}
