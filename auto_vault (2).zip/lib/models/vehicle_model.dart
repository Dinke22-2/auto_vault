class Vehicle {
   String id;
   String make;
   String model;
   String registrationNumber;

   Vehicle({required this.id, required this.make, required this.model, required this.registrationNumber});
}
